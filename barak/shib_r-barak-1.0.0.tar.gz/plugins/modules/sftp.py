# -*- coding: utf-8 -*-

# Copyright: (c) 2020, Konstantinos Georgoudis <kgeor@blacklines.gr>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r'''
---
collection: barak
module: sftp

short_description: download and upload 

version_added: "1.0.0"

description:
    - Use to uplad and download files to or from sftp server.

options:
    src:
    description:
            - The source file path. For downloads, this is the remote file path on the SFTP server. For uploads, this is the local file path.
    required: true
    type: str

    dest:
        description:
            - The destination file path. For downloads, this is the local file path. For uploads, this is the remote file path on the SFTP server.
        required: true
        type: str

    state:
        description:
            - Specifies the action to perform. It can be either 'download' or 'upload'.
        required: true
        type: str
        choices:
            - download
            - upload
    host:
        description:
            - The IP address or the FQDN of the remote SFTP host.
        required: true
        type: str

    port:
        description:
            - The TCP port of the remote SFTP host. The default port is 22.
        type: int
        default: 22

    username:
        description:
            - Username for the SFTP connection.
        required: true
        type: str

    password:
        description:
            - Password for the SFTP connection. Required if 'private_key' is not provided.
        type: str
        no_log: true
        default: None

    private_key:
        description:
            - Path to the private key file for key-based authentication. Required if 'password' is not provided.
        type: str
        default: None

requirements:
    paramiko>=2.7.2

'''

EXAMPLES = r'''

---
- name: SFTP File Transfer Example
  hosts: localhost
  gather_facts: no
  tasks:
    - name: Download file from SFTP server
      shib_r.barak.sftp:
        src: /remote/path/to/file.txt
        dest: /local/path/to/save/file.txt
        state: download
        host: sftp.example.com
        port: 22
        username: my_user
        password: my_password

    - name: Upload file to SFTP server
      shib_r.barak.sftp:
        src: /local/path/to/upload/file.txt
        dest: /remote/path/to/save/uploaded_file.txt
        state: upload
        host: sftp.example.com
        port: 22
        username: my_user
        private_key: /path/to/private_key
      delegate_to: localhost
  
'''


from ansible.module_utils.basic import AnsibleModule
import paramiko

def sftp_file(module):
# Get parameters
    src = module.params.get('src')
    dest = module.params.get('dest')
    state = module.params.get('state')
    host = module.params.get('host')
    port = module.params.get('port')
    username = module.params.get('username')
    password = module.params.get('password')
    private_key = module.params.get('private_key')


# Initialize SSH client
    ssh = paramiko.SSHClient()
# Automatically add the server's host key (not secure, but useful for testing)
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

# if private key exists use it. use connect using password.
    try:
        if private_key:
            private_key = paramiko.RSAKey.from_private_key_file(private_key)
            ssh.connect(host, port=port,
                        username=username, pkey=private_key)
        else:
            ssh.connect(host, 
                        port=port,
                        username=username,
                        password=password)
    except Exception as e:
# If connection fails, return an error message and exit
        module.fail_json(msg=f"Failed to connect to {host}: {str(e)}")

# Start SFTP operation.
    try:
# Open SFTP session
        sftp = ssh.open_sftp()
        if state == 'download':
            sftp.get(src, dest)
            result = {"changed": True, "msg": "File downloaded successfully"}
        elif state == 'upload':
            sftp.put(src, dest)
            result = {"changed": True, "msg": "File uploaded successfully"}
        else:
            result = {"changed": False, "msg": "Invalid state"}
    except Exception as e:
# If an SFTP operation fails, return an error message and exit
        module.fail_json(msg=f"Failed to perform SFTP operation: {str(e)}")
    finally:
# Make sure session is closed.
        sftp.close()
        ssh.close()

    return result

# Get parameters
def main():
# Define the module's argument specification
    module_args = dict(
        src=dict(type='str', required=True),
        dest=dict(type='str', required=True),
        state=dict(type='str', required=True, choices=['download', 'upload']),
        host=dict(type='str', required=True),
        port=dict(type='int', default=22),
        username=dict(type='str', required=True),
        password=dict(type='str', required=True, no_log=True),
        private_key=dict(type='str', default=None)
    )

# Initialize Ansible module
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

# Start sftp_file function and print results.
    result = sftp_file(module)
    module.exit_json(**result)

if __name__ == '__main__':
    main()

